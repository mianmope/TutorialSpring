package com.capgemini.ccsw.tutorial.clientes;

import java.util.List;

import com.capgemini.ccsw.tutorial.clientes.model.Cliente;
import com.capgemini.ccsw.tutorial.clientes.model.ClienteDto;

public interface ClienteService {

    /**
    * Recupera una {@link com.capgemini.ccsw.tutorial.clientes.model.Cliente} a partir de su ID
    * @param id
    * @return
    */
    Cliente get(Long id);

    /**
    * Método para recuperar todas las {@link com.capgemini.ccsw.tutorial.clientes.model.Cliente}
    * @return
    */
    List<Cliente> findAll();

    /**
    * Método para crear o actualizar una {@link com.capgemini.ccsw.tutorial.clientes.model.Cliente}
    * @param dto
    * @return
    */
    void save(Long id, ClienteDto dto);

    /**
    * Método para borrar una {@link com.capgemini.ccsw.tutorial.clientes.model.Cliente}
    * @param id
    */
    void delete(Long id);
}
