package com.capgemini.ccsw.tutorial.prestamo.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


import com.capgemini.ccsw.tutorial.clientes.model.Cliente;
import com.capgemini.ccsw.tutorial.game.model.Game;

@Entity
@Table(name = "Prestamo")
public class Prestamo {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;
	
	@ManyToOne
    @JoinColumn(name = "game_id", nullable = false)
    private Game game;
    
    @ManyToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;
    

    @Column(name = "date_ini", nullable = false)
    private Date date_ini;
    
    @Column(name = "date_fin", nullable = false)
    private Date date_fin;

    /**
    * @return id
    */
    public Long getId() {

        return this.id;
    }

    /**
    * @param id new value of {@link #getId}.
    */
    public void setId(Long id) {

        this.id = id;
    }

    /**
    * @return Game
    */
    public Game getGame() {

        return this.game;
    }

    /**
    * @param game new value of {@link #getGame}.
    */
    public void setGame(Game game) {

        this.game = game;
    }
    /**
     * @return Cliente
     */
     public Cliente getCliente() {

         return this.cliente;
     }

     /**
     * @param Cliente new value of {@link #getCliente}.
     */
     public void setCliente(Cliente cliente) {

         this.cliente = cliente;
     }
    
    /**
    * @return data
    */
    public Date getDateIni() {

        return this.date_ini;
    }
    
    /**
     * @param Date new value of {@link #getDateIni}.
     */
     public void setDateIni(Date date_ini) {

         this.date_ini = date_ini;
     }
     
     /**
      * @return data
      */
      public Date getDateFin() {

          return this.date_fin;
      }
      
      /**
       * @param Date new value of {@link #getDateFin}.
       */
       public void setDateFin(Date date_fin) {

           this.date_fin = date_fin;
       }

    


}
