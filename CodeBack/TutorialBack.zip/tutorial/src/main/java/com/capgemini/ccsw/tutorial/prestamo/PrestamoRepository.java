package com.capgemini.ccsw.tutorial.prestamo;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.capgemini.ccsw.tutorial.game.model.Game;
import com.capgemini.ccsw.tutorial.prestamo.model.Prestamo;



public interface PrestamoRepository extends CrudRepository<Prestamo, Long> {
    /**
    * Método para recuperar un listado paginado de {@link com.capgemini.ccsw.tutorial.prestamo.model.Prestamo}
    * @param page
    * @return
    */
	
	@Query("select p from Prestamo p where (:title is null or p.game.id = :title) and (:idCliente is null or p.cliente.id = :idCliente) and (:filterDate is null or ((p.date_ini < :filterDate) and (p.date_fin > :filterDate)))")
    Page<Prestamo> findAll(Pageable pageable, @Param("title") Long title, @Param("idCliente") Long idCliente, @Param("filterDate") Date filterDate);
    
    @Query("select p from Prestamo p where (p.cliente.id = :id)")
    List<Prestamo> findPrestamosCliente(@Param("id")Long id);
    
    @Query("select p from Prestamo p where (p.game.id = :id)")
    List<Prestamo> findPrestamosGame(@Param("id")Long id);
    
}
