package com.capgemini.ccsw.tutorial.prestamo;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;


import com.capgemini.ccsw.tutorial.prestamo.model.Prestamo;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoDto;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoSearchDto;

public interface PrestamoService {
	/**
	* Recupera un listado de prestamo
	* @return
	*/
	List<Prestamo> findAll();
    /**
    * Recupera un {@link com.capgemini.ccsw.tutorial.prestamo.model.Prestamo} a través de su ID
    * @param id
    * @return
    */
	Prestamo get(Long id);

    /**
    * Método para recuperar un listado paginado de {@link com.capgemini.ccsw.tutorial.prestamo.model.Prestamo}
    * @param dto
    * @return
    */
    Page<Prestamo> findPage(PrestamoSearchDto dto, Long title, Long idCliente, Date filterDate);

    /**
    * Método para crear o actualizar un {@link com.capgemini.ccsw.tutorial.prestamo.model.Prestamo}
    * @param id
    * @param data
    */
    void save(Long id, PrestamoDto data);

    public boolean comprobarFecha(PrestamoDto data);
    
    public boolean comprobarPrestamo(PrestamoDto data);
    
    public List<Prestamo> findPrestamosCliente(Long id);
    
    public List<Prestamo> findPrestamosGame(Long id);
    
    public boolean comprobarPrestamosJuego(PrestamoDto data);
    
    /**
    * Método para crear o actualizar un {@link com.capgemini.ccsw.tutorial.prestamo.model.Prestamo}
    * @param id
    */
    void delete(Long id);
}
