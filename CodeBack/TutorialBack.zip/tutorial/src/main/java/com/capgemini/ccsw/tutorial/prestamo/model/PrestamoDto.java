package com.capgemini.ccsw.tutorial.prestamo.model;

import java.sql.Date;


import com.capgemini.ccsw.tutorial.clientes.model.ClienteDto;
import com.capgemini.ccsw.tutorial.game.model.GameDto;

public class PrestamoDto {

	private Long id;
	private GameDto game;
	private ClienteDto cliente;
	private Date date_ini;
	private Date date_fin;
	
    /**
    * @return id
    */
    public Long getId() {

        return this.id;
    }

    /**
    * @param id new value of {@link #getId}.
    */
    public void setId(Long id) {

        this.id = id;
    }

    /**
    * @return Game
    */
    public GameDto getGame() {

        return this.game;
    }

    /**
    * @param game new value of {@link #getGame}.
    */
    public void setGame(GameDto game) {

        this.game = game;
    }
    /**
     * @return Cliente
     */
     public ClienteDto getCliente() {

         return this.cliente;
     }

     /**
     * @param Cliente new value of {@link #getCliente}.
     */
     public void setCliente(ClienteDto cliente) {

         this.cliente = cliente;
     }
    
    /**
    * @return data
    */
    public Date getDateIni() {

        return this.date_ini;
    }
    
    /**
     * @param Date new value of {@link #getDateIni}.
     */
     public void setDateIni(Date date_ini) {

         this.date_ini = date_ini;
     }
     
     /**
      * @return data
      */
      public Date getDateFin() {

          return this.date_fin;
      }
      
      /**
       * @param Date new value of {@link #getDateFin}.
       */
       public void setDateFin(Date date_fin) {

           this.date_fin = date_fin;
       }

}
