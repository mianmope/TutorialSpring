package com.capgemini.ccsw.tutorial.clientes;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.ccsw.tutorial.clientes.model.Cliente;

/**
* @author ccsw
*/
public interface ClienteRepository extends CrudRepository<Cliente, Long> {

}