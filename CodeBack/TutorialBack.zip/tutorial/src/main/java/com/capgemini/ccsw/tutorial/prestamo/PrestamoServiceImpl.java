package com.capgemini.ccsw.tutorial.prestamo;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.capgemini.ccsw.tutorial.author.model.Author;
import com.capgemini.ccsw.tutorial.clientes.ClienteService;
import com.capgemini.ccsw.tutorial.game.GameService;
import com.capgemini.ccsw.tutorial.prestamo.model.Prestamo;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoDto;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoSearchDto;


@Service
@Transactional
public class PrestamoServiceImpl implements PrestamoService{
	
	 	@Autowired
	    PrestamoRepository prestamoRepository;
	 	
	 	@Autowired
	 	ClienteService clienteService;
	 	
	 	@Autowired
	 	GameService gameService;

	    /**
	    * {@inheritDoc}
	    */
	    @Override
	    public Prestamo get(Long id) {

	        return this.prestamoRepository.findById(id).orElse(null);
	    }

	    /**
	    * {@inheritDoc}
	    */
	    @Override
	    public Page<Prestamo> findPage(PrestamoSearchDto dto,Long title, Long idCliente, Date filterDate) {

	    	//Si los filtros son null o no !
	        return this.prestamoRepository.findAll(dto.getPageable(),title, idCliente, filterDate);
	    }

	    /**
	    * {@inheritDoc}
	    */
	    @Override
	    public void save(Long id, PrestamoDto data) {
	    
	    	if(comprobarFecha(data) && comprobarPrestamosJuego(data) && comprobarPrestamo(data)) {
	    		
	    		Prestamo prestamo = new Prestamo();
		    	
		        BeanUtils.copyProperties(data, prestamo);
		        prestamo.setCliente(clienteService.get(data.getCliente().getId()));
		        prestamo.setGame(gameService.get(data.getGame().getId()));
		      
		        this.prestamoRepository.save(prestamo);
	    	}
	    	
	        
	     
	    }
	    @Override
	    public boolean comprobarPrestamo(PrestamoDto data) {
	    
	    	//System.out.println("--------------- COMPROBAR PRESTAMOS --------");
	    	boolean ok = false;
	    	List<Prestamo> prestamos = findPrestamosCliente(data.getCliente().getId());
	    	
	    	if(prestamos.isEmpty()) {
	    		//System.out.println("--------------- CLIENTE SIN PRESTAMOS --------");
	    		ok = true; //No tiene prestamos
	    	}
	    	else if(!prestamos.isEmpty()) {
	    		//System.out.println("--------------- CLIENTE CON PRESTAMOS --------");
	    		//1 Cliente solo puede tener como maximo 2 Prestamos
	    		//ComprobarFecha
	    		if((prestamos.get(0).getDateIni().getTime() > data.getDateFin().getTime())
	    				|| prestamos.get(0).getDateFin().getTime() < data.getDateIni().getTime()) {
	    			//Comprobar si ese juego esta prestado a otros Clientes!
	    			ok = true;
	    		}
	    		
	    	}
	    	
	    	return ok;
	    }
	    @Override
	    public boolean comprobarPrestamosJuego(PrestamoDto data) {
	    	
	    	boolean ok = false;
	    	boolean bandera = false;
	    	
	    	List<Prestamo> prestamos = findPrestamosGame(data.getGame().getId());
	    	
	    	if(prestamos.size() == 0) {
	    		ok = true;
	    	}
	    	else {
	    		for(int i = 0; i < prestamos.size() && !bandera; i++) {
		    		//System.out.println("Prestamos: " + prestamos.get(i).getGame().getTitle() + " del cliente: " + prestamos.get(i).getCliente().getName());
		    		if((prestamos.get(i).getDateIni().getTime() > data.getDateFin().getTime())
		    				|| (prestamos.get(i).getDateFin().getTime() < data.getDateIni().getTime())) {
		    			//System.out.println("No colision rangos de fechas");
		    			ok = true;
		    			bandera = true; //Si encontramos una fecha que se solape salimos del bucle y devolvemos False!
		    		}
	    		}
	    	
	    	}
	    	//System.out.println("ComprobarPrestamosJuego: " + ok);
	    	return ok;
	    }
	  
	    @Override
	    public boolean comprobarFecha(PrestamoDto data) {
	    	
	    	boolean ok = false;
	    	
	    	Date dateIni = data.getDateIni();
	    	Date dateFin = data.getDateFin();
	    	//System.out.println("dateIni: " + dateIni);
	    	//System.out.println("dateFin: " + dateFin);
	    	if(dateFin.getTime() > dateIni.getTime()) {
	    		//System.out.println("------CF --> dateFin > dateIni");
	    		float dias = (dateFin.getTime() - dateIni.getTime())/(1000*60*60*24);
	    		if(dias <= 14) {
	    			//System.out.println("------CF --> dias <= 14");
	    			ok = true;
	    		}
	    	}
	    	//System.out.println("comprobarFecha : " + ok);
	    	return ok;
	    }
	    @Override
	    public List<Prestamo> findPrestamosGame(Long id){
	    	return(List<Prestamo>)this.prestamoRepository.findPrestamosGame(id);
	    }
	    @Override
	    public List<Prestamo> findPrestamosCliente(Long id){
	    	return(List<Prestamo>)this.prestamoRepository.findPrestamosCliente(id);
	    }

	    /**
	    * {@inheritDoc}
	    */
	    @Override
	    public void delete(Long id) {

	        this.prestamoRepository.deleteById(id);

	    }
	    /**
	    * {@inheritDoc}
	    */
	    @Override
	    public List<Prestamo> findAll() {

	        return (List<Prestamo>) this.prestamoRepository.findAll();
	    }
}
