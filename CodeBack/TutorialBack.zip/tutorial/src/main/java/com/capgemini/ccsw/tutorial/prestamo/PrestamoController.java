package com.capgemini.ccsw.tutorial.prestamo;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.ccsw.tutorial.author.model.AuthorDto;
import com.capgemini.ccsw.tutorial.author.model.AuthorSearchDto;
import com.capgemini.ccsw.tutorial.config.mapper.BeanMapper;
import com.capgemini.ccsw.tutorial.game.model.Game;
import com.capgemini.ccsw.tutorial.game.model.GameDto;
import com.capgemini.ccsw.tutorial.prestamo.model.Prestamo;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoDto;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoSearchDto;

@RequestMapping(value = "/prestamo")
@RestController
@CrossOrigin(origins = "*")
public class PrestamoController {
	
	@Autowired
    PrestamoService prestamoService;

    @Autowired
    BeanMapper beanMapper;

    /**
    * Método para recuperar un listado paginado de {@link com.capgemini.ccsw.tutorial.prestamo}
    * @param dto
    * @return
    */
 
    @RequestMapping(path = "", method = RequestMethod.POST)
    public Page<PrestamoDto> findPage(@RequestParam(value = "title", required = false) Long title,
    		 @RequestParam(value = "idCliente", required = false) Long idCliente, @RequestParam(value = "filterDate",required = false) Date filterDate, @RequestBody PrestamoSearchDto dto) {

        return this.beanMapper.mapPage(this.prestamoService.findPage(dto,title,idCliente,filterDate), PrestamoDto.class);
    }

    /**
    * Método para crear o actualizar un {@link com.capgemini.ccsw.tutorial.author.model.Author}
    * @param id
    * @param data datos de la entidad 
    */
    @RequestMapping(path = { "", "/{id}" }, method = RequestMethod.PUT)
    public void save(@PathVariable(name = "id", required = false) Long id, @RequestBody PrestamoDto data) {

        this.prestamoService.save(id, data);
    }

    /**
    * Método para crear o actualizar un {@link com.capgemini.ccsw.tutorial.author.model.Author}
    * @param id PK de la entidad
    */
    @RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
    public void delete(@PathVariable("id") Long id) {

        this.prestamoService.delete(id);
    }
    /**
    * Recupera un listado de autores
    * @return
    */
    public List<PrestamoDto> findAll() {

        List<Prestamo> prestamos = this.prestamoService.findAll();

        return this.beanMapper.mapList(prestamos, PrestamoDto.class);
    }
}
