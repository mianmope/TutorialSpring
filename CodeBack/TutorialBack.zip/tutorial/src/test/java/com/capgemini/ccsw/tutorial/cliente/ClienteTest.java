package com.capgemini.ccsw.tutorial.cliente;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ccsw.tutorial.category.model.CategoryDto;
import com.capgemini.ccsw.tutorial.clientes.ClienteController;
import com.capgemini.ccsw.tutorial.clientes.model.ClienteDto;



@SpringBootTest
@Transactional
public class ClienteTest {
	
	@Autowired
	private ClienteController clienteController;
	
	@Test
	public void findAllShouldReturnAllCategoriesInBD() {
		
		assertNotNull(clienteController);
		
		long clientesSize = 3;
		
		List<ClienteDto> clientes = clienteController.findAll();
		
		assertNotNull(clientes);
		assertEquals(clientesSize, clientes.size());
	}
	
	@Test
	public void saveWithoutIdShouldCreatNewCliente() {
		assertNotNull(clienteController);
		String newClienteName = "Nuevo Cliente";
		long newClienteId = 4;
		long newClienteSize = newClienteId;
		
		ClienteDto dto = new ClienteDto();
		dto.setName(newClienteName);
		
		clienteController.save(null, dto);
		
		List<ClienteDto> clientes = clienteController.findAll();
		assertNotNull(clientes);
		assertEquals(newClienteSize, clientes.size());
		
		System.out.println("-----------------------------------------Tamaño Lista: " + clientes.size());
		ClienteDto clienteSearch = clientes.stream().filter(item -> item.getId().equals(newClienteId)).findFirst().orElse(null);
		System.out.println("----------------------------------------- Nombre Cliente " + clienteSearch.getName());
		assertNotNull(clienteSearch);
		assertEquals(newClienteName,clienteSearch.getName());
	
			
	}
	
	 @Test
	  public void modifyWithExistsIdShouldModifyCliente() {

	      assertNotNull(clienteController);

	      String newClienteName = "Nuevo Cliente";
	      long clienteId = 3;
	      long clienteSize = 3;

	      ClienteDto dto = new ClienteDto();
	      dto.setName(newClienteName);

	      clienteController.save(clienteId, dto);

	      List<ClienteDto> clientes = clienteController.findAll();
	      assertNotNull(clientes);
	      assertEquals(clienteSize, clientes.size());

	      ClienteDto clienteSearch = clientes.stream().filter(item -> item.getId().equals(clienteId)).findFirst().orElse(null);
	      assertNotNull(clienteSearch);
	      assertEquals(newClienteName, clienteSearch.getName());

	  }
	  @Test
	  public void modifyWithNotExistsIdShouldThrowException() {

	      assertNotNull(clienteController);

	      String newClienteName = "Nuevo Cliente";
	      long clienteId = 4;

	      ClienteDto dto = new ClienteDto();
	      dto.setName(newClienteName);

	      //Esperamos que el metodo Save Lance un NullPointerException
	      assertThrows(NullPointerException.class, () -> clienteController.save(clienteId, dto));
	  }
	  @Test
	  public void deleteWithExistsIdShouldDeleteCliente() {

	      assertNotNull(clienteController);

	      long newClienteSize = 2;
	      long deleteClienteId = 2;

	      clienteController.delete(deleteClienteId);

	      List<ClienteDto> clientes = clienteController.findAll();

	      assertNotNull(clientes);
	      assertEquals(newClienteSize, clientes.size());

	  }

	  @Test
	  public void deleteWithNotExistsIdShouldThrowException() {

	      assertNotNull(clienteController);

	      long deleteClienteId = 4;

	      assertThrows(Exception.class, () -> clienteController.delete(deleteClienteId));

	  }
	  @Test
	  public void modifyWithNotExistsIdAndRepeatNameShouldThrowException() {
		  
		  assertNotNull(clienteController);

	      String newClienteName = "Miguel";
	      long clienteId = 2;

	      ClienteDto dto = new ClienteDto();
	      dto.setName(newClienteName);

	      //Esperamos que la BD lance excepcion al modificar elemento con Nombre ya existente
	      assertThrows(Exception.class, () -> clienteController.save(clienteId, dto));
		  
	  }
	  @Test
		public void saveWithoutIdandRepeatNameShouldThrowException() {
			assertNotNull(clienteController);
			String newClienteName = "Miguel";
			long newClienteId = 4;
			long newClienteSize = newClienteId;
			
			ClienteDto dto = new ClienteDto();
			dto.setName(newClienteName);
			
			  //Esperamos que la BD lance excepcion al modificar elemento con Nombre ya existente
			assertThrows(Exception.class, () -> clienteController.save(null, dto));
				
		}
	
	
	
	
	
	
	
	
	
	

}
