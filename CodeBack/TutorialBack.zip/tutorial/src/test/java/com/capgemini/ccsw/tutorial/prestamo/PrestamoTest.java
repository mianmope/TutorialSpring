package com.capgemini.ccsw.tutorial.prestamo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ccsw.tutorial.author.model.AuthorDto;
import com.capgemini.ccsw.tutorial.author.model.AuthorSearchDto;
import com.capgemini.ccsw.tutorial.category.model.CategoryDto;
import com.capgemini.ccsw.tutorial.clientes.model.ClienteDto;
import com.capgemini.ccsw.tutorial.game.GameController;
import com.capgemini.ccsw.tutorial.game.model.GameDto;
import com.capgemini.ccsw.tutorial.prestamo.model.Prestamo;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoDto;
import com.capgemini.ccsw.tutorial.prestamo.model.PrestamoSearchDto;

@SpringBootTest
@Transactional
public class PrestamoTest {

	private static final int TOTAL_PRESTAMOS = 3;
	
	  @Autowired
	  private PrestamoController prestamoController;
	 
	 /* @Test
	    public void findFirstPageWithFiveSizeShouldReturnFirstFiveResults() {

	        int pageSize = 3;

	        assertNotNull(prestamoController);

	        PrestamoSearchDto dto = new PrestamoSearchDto();
	        dto.setPageable(PageRequest.of(0, pageSize));

	        Page<PrestamoDto> resultPage = prestamoController.findPage(dto);

	        assertNotNull(resultPage);

	        assertEquals(TOTAL_PRESTAMOS, resultPage.getTotalElements());
	        assertEquals(pageSize, resultPage.getContent().size());

	    }

	  
	    @Test
	    public void findSecondPageWithFiveSizeShouldReturnLastTwoResults() {

	        int pageSize = 3;
	        int elementsCount = TOTAL_PRESTAMOS - pageSize;

	        assertNotNull(prestamoController);

	        PrestamoSearchDto searchDto = new PrestamoSearchDto();
	        searchDto.setPageable(PageRequest.of(1, pageSize));

	        Page<PrestamoDto> resultPage = prestamoController.findPage(searchDto);

	        assertNotNull(resultPage);

	        assertEquals(TOTAL_PRESTAMOS, resultPage.getTotalElements());
	        assertEquals(elementsCount, resultPage.getContent().size());

	    }
	 @Test
	    public void saveCreateNewPrestamoShouldCreateNewPrestamo() {

		 	assertNotNull(prestamoController);
		
	        GameDto gameDto = new GameDto();
	        gameDto.setId(1L);

	        ClienteDto clienteDto = new ClienteDto();
	        clienteDto.setId(1L);
	     
	        long newPrestamoId = TOTAL_PRESTAMOS + 1;
	        long newPrestamoSize = TOTAL_PRESTAMOS + 1;
	        
	        PrestamoDto dto = new PrestamoDto();
	        dto.setCliente(clienteDto);
	        dto.setGame(gameDto);

	        prestamoController.save(null, dto);

	        PrestamoSearchDto searchDto = new PrestamoSearchDto();
	        searchDto.setPageable(PageRequest.of(0, (int) newPrestamoSize));

	        Page<PrestamoDto> resultPage = prestamoController.findPage(searchDto);

	        assertNotNull(resultPage);
	        assertEquals(newPrestamoSize, resultPage.getTotalElements());

	        PrestamoDto prestamo = resultPage.getContent().stream().filter(item -> item.getId().equals(newPrestamoId)).findFirst().orElse(null);
	        assertNotNull(prestamo);
	       
	    }*/
	  
}
